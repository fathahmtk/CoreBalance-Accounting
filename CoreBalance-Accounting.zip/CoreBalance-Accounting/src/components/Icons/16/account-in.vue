<template>
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 14 12">
    <g
      fill="none"
      fill-rule="evenodd"
      stroke-linecap="round"
      stroke-linejoin="round"
      transform="translate(0 1)"
    >
      <g transform="rotate(180 4.5 3.5)">
        <polyline points="0 2 2 0 4 2" />
        <path d="M2,0 L2,7" />
      </g>
      <path
        d="M3.5,1.5 L1.5,1.5 C0.94771525,1.5 0.5,1.94771525 0.5,2.5 L0.5,9.5 C0.5,10.0522847 0.94771525,10.5 1.5,10.5 L12.5,10.5 C13.0522847,10.5 13.5,10.0522847 13.5,9.5 L13.5,2.5 C13.5,1.94771525 13.0522847,1.5 12.5,1.5 L10.5,1.5"
      />
    </g>
  </svg>
</template>
