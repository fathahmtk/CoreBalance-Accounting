<template>
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 12 10">
    <path
      stroke-linecap="round"
      stroke-linejoin="round"
      d="M1.5,0.5 L10.5,0.5 C11.0522847,0.5 11.5,0.94771525 11.5,1.5 L11.5,8.5 C11.5,9.05228475 11.0522847,9.5 10.5,9.5 L1.5,9.5 C0.94771525,9.5 0.5,9.05228475 0.5,8.5 L0.5,1.5 C0.5,0.94771525 0.94771525,0.5 1.5,0.5 Z"
    />
  </svg>
</template>
