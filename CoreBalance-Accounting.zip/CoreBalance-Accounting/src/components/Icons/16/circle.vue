<template>
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 8 8">
    <circle cx="8" cy="8" r="3.5" fill="none" transform="translate(-4 -4)" />
  </svg>
</template>
