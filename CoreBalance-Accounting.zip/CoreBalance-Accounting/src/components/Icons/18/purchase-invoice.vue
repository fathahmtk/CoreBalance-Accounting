<template>
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18">
    <path
      fill="#4ADAFC"
      d="M14.25,0 L0.75,0 C0.336,0 0,0.33525 0,0.75 L0,18 L3,15.75 L5.25,18 L7.5,15.75 L9.75,18 L12,15.75 L15,18 L15,0.75 C15,0.33525 14.664,0 14.25,0 Z M8.25,12 L3,12 L3,10.5 L8.25,10.5 L8.25,12 Z M8.25,9 L3,9 L3,7.5 L8.25,7.5 L8.25,9 Z M8.25,6 L3,6 L3,4.5 L8.25,4.5 L8.25,6 Z M12,12 L9.75,12 L9.75,10.5 L12,10.5 L12,12 Z M12,9 L9.75,9 L9.75,7.5 L12,7.5 L12,9 Z M12,6 L9.75,6 L9.75,4.5 L12,4.5 L12,6 Z"
      transform="translate(1.5)"
    />
  </svg>
</template>
<script>
import Base from '../base.vue';
export default {
  extends: Base,
};
</script>
