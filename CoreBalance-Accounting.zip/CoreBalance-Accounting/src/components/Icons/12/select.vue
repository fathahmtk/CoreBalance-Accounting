<template>
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 5 10">
    <path
      stroke-linecap="round"
      stroke-linejoin="round"
      d="M4,3.63636364 L5.63636364,2 L7.27272727,3.63636364 M4,8.36363636 L5.63636364,10 L7.27272727,8.36363636"
      transform="translate(-3 -1)"
    />
  </svg>
</template>
