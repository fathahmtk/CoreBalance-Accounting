# Reports

Reports are a view of stored data, the code here doesn't alter any data.

All reports should extend the `Report` class in `reports/Report.ts`, depending
on the report it may have custom `.vue` files. Check the `type.ts` file for the
shape of the report data.
