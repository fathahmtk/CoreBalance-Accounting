<template>
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2 9">
    <path
      d="M1 6.4a.833.833 0 110 1.667A.833.833 0 011 6.4zm0-3.2a.833.833 0 110 1.667A.833.833 0 011 3.2zM1 0a.833.833 0 110 1.667A.833.833 0 011 0z"
      fill-rule="nonzero"
    />
  </svg>
</template>
