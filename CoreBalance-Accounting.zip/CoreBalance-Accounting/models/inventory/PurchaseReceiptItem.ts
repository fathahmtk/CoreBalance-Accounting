import { StockTransferItem } from './StockTransferItem';

export class PurchaseReceiptItem extends StockTransferItem {}
