import { InvoiceItem } from '../InvoiceItem/InvoiceItem';

export class SalesQuoteItem extends InvoiceItem {}
