<template>
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 10 4">
    <polyline
      fill="none"
      stroke-linecap="round"
      stroke-linejoin="round"
      points="4 6 8 10 12 6"
      transform="translate(-3 -6)"
    />
  </svg>
</template>
