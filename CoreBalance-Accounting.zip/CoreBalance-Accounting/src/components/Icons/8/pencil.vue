<template>
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 10 10">
    <path
      d="M7 1.4L8.6 3 3.8 7.8l-2.4.8.8-2.4z"
      fill-rule="evenodd"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>
</template>
