import { InvoiceItem } from '../InvoiceItem/InvoiceItem';

export class PurchaseInvoiceItem extends InvoiceItem {}
