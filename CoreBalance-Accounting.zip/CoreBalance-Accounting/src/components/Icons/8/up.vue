<template>
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 6 8">
    <g fill-rule="nonzero">
      <path d="M0 3h6L3 0z" />
      <path opacity=".5" d="M3 8l3-3H0z" />
    </g>
  </svg>
</template>
