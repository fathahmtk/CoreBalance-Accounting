import { CashDenominations } from './CashDenominations';

export class OpeningCash extends CashDenominations {
  count?: number;
}
