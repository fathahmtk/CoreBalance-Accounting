import { CashDenominations } from './CashDenominations';

export class ClosingCash extends CashDenominations {
  count?: number;
}
