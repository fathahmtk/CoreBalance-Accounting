<template>
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 8 8">
    <path
      d="M7.2.8L.8 7.2m6.4 0L.8.8"
      fill-rule="evenodd"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>
</template>
