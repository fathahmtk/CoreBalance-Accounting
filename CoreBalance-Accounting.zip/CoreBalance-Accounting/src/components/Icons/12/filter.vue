<template>
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 12 10">
    <path
      stroke-linecap="round"
      stroke-linejoin="round"
      d="M11.2 1.5L.8 1.5M3 5.75L9 5.75M5 10.5L7 10.5"
      transform="translate(0 -2)"
    />
  </svg>
</template>
