import { StockTransferItem } from './StockTransferItem';

export class ShipmentItem extends StockTransferItem {}
