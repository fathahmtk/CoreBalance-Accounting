<template>
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 9">
    <polyline
      fill="none"
      stroke-linecap="round"
      stroke-linejoin="round"
      stroke-width="1.5"
      points="1 5 8 12 15 5"
      transform="translate(0 -4)"
    />
  </svg>
</template>
