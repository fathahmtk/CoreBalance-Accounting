<template>
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 8 2">
    <path
      d="M1.633 1.033a.833.833 0 11-1.666 0 .833.833 0 011.666 0zm3.2 0a.833.833 0 11-1.666 0 .833.833 0 011.666 0zm3.2 0a.833.833 0 11-1.666 0 .833.833 0 011.666 0z"
      fill-rule="nonzero"
    />
  </svg>
</template>
