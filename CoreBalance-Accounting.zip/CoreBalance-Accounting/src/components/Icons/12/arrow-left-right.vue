<template>
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 12 11">
    <path
      stroke-linecap="round"
      stroke-linejoin="round"
      d="M2.25 2.25L9 2.25 2.25 2.25 2.25 4.5 0 2.25 2.25 0 2.25 2.25zM8.75 7.875L2 7.875 8.75 7.875 8.75 5.625 11 7.875 8.75 10.125 8.75 7.875z"
      transform="translate(.5)"
    />
  </svg>
</template>
