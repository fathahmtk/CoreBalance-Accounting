<template>
  <div class="flex items-baseline justify-between dark:text-white">
    <span class="font-semibold text-base"><slot name="title"></slot></span>
    <slot name="action"></slot>
  </div>
</template>
