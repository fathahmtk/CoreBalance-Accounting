<template>
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 15">
    <path
      fill="none"
      stroke-linecap="round"
      stroke-linejoin="round"
      d="M7,13 C10.3137085,13 13,10.3137085 13,7 C13,3.6862915 10.3137085,1 7,1 C3.6862915,1 1,3.6862915 1,7 C1,10.3137085 3.6862915,13 7,13 Z M15,15 L11.242,11.242"
    />
  </svg>
</template>
