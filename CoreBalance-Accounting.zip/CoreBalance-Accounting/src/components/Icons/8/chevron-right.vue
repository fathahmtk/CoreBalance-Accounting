<template>
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 6 8">
    <path
      d="M1.25 7.75l3.5-3.5-3.5-3.5"
      fill-rule="evenodd"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>
</template>
