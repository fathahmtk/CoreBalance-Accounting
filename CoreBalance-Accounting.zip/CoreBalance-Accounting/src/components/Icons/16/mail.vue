<template>
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 14">
    <g fill="none" fill-rule="evenodd">
      <path
        fill="#A1ABB4"
        d="M15,0 L1,0 C0.4,0 0,0.4 0,1 L0,2.4 L8,6.9 L16,2.5 L16,1 C16,0.4 15.6,0 15,0 Z"
      />
      <path
        fill="#415668"
        fill-rule="nonzero"
        d="M7.5,8.9 L0,4.7 L0,13 C0,13.6 0.4,14 1,14 L15,14 C15.6,14 16,13.6 16,13 L16,4.7 L8.5,8.9 C8.22,9.04 7.78,9.04 7.5,8.9 Z"
      />
    </g>
  </svg>
</template>
