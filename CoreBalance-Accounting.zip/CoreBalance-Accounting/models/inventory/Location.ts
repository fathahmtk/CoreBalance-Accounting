import { Doc } from 'fyo/model/doc';

export class Location extends Doc {
  item?: string;
}
