<template>
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 8 7">
    <g fill-rule="evenodd" stroke-linecap="round" stroke-linejoin="round">
      <path d="M6.8 4.002L.8 4M4.6 1.335l2.667 2.667L4.6 6.668" />
    </g>
  </svg>
</template>
