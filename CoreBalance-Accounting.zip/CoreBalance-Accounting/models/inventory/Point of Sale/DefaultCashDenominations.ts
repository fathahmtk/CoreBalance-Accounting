import { CashDenominations } from './CashDenominations';

export class DefaultCashDenominations extends CashDenominations {}
