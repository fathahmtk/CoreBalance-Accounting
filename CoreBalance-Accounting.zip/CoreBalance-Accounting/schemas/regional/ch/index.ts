import { SchemaStub } from '../../types';
import AccountingSettings from './AccountingSettings.json';

export default [AccountingSettings] as SchemaStub[];
