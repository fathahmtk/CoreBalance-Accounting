export type GSTType = 'Unregistered' | 'Registered Regular' | 'Consumer';
