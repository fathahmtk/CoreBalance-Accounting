<template>
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 8 8">
    <path
      d="M4 .8v6.4M7.2 4H.8"
      fill-rule="evenodd"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>
</template>
