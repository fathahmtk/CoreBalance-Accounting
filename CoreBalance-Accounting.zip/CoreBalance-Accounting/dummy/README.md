# Dummy

This will be used to generate dummy data for the purposes of tests and to create
a demo instance.

There are a few `.json` files here (eg: `items.json`) which have been generated,
these are not to be edited.

The generated data has some randomness, there is a `baseCount` arg to the
exported `setupDummyInstance` function, the number of transactions generated are
always more than this.
