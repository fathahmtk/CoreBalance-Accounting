import { Doc } from 'fyo/model/doc';

export class PricingRuleDetail extends Doc {
  referenceName?: string;
  referenceItem?: string;
}
