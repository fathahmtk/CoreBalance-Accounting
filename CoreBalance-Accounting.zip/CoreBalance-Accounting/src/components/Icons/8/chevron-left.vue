<template>
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 6 10">
    <path
      d="M4.75 8.5L1.25 5l3.5-3.5"
      stroke-width="1.5"
      fill-rule="evenodd"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>
</template>
