export type PartyRole = 'Both' | 'Supplier' | 'Customer';
export enum PartyRoleEnum {
  'Both' = 'Both',
  'Supplier' = 'Supplier',
  'Customer' = 'Customer',
}
