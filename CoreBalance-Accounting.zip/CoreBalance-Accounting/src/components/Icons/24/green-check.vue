<template>
  <svg width="24" height="24" xmlns="http://www.w3.org/2000/svg">
    <g fill="none" fill-rule="evenodd">
      <path
        d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12C23.98 5.38 18.62.02 12 0z"
        fill="#92D336"
        fill-rule="nonzero"
      />
      <path
        stroke="#FFF"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
        d="M8 12.756l2.222 2.4L16 9.022"
      />
    </g>
  </svg>
</template>
<script>
import Base from '../base.vue';
export default {
  name: 'IconGreenCheck',
  extends: Base,
};
</script>
